<?php
/**
 * front-page.php — Homepage Dentix
 * Las categorías y productos se cargan dinámicamente desde WooCommerce.
 */
get_header();

$show_hero     = dentix_opt('show_hero', 1);
$show_cats     = dentix_opt('show_cats', 1);
$show_featured = dentix_opt('show_featured', 1);
$wc_cats       = function_exists('dentix_get_wc_categories') ? dentix_get_wc_categories() : [];
?>

<?php if ($show_hero) : ?>
<!-- ═══ HERO CON CARRUSEL ════════════════════════════════════════ -->
<section class="hero">
  <div class="hero-carousel">
    <div class="hero-slide hs1 active"></div>
    <div class="hero-slide hs2"></div>
    <div class="hero-slide hs3"></div>
    <div class="hero-slide hs4"></div>
    <div class="hero-slide hs5"></div>
    <div class="hero-carousel-overlay"></div>
  </div>
  <div class="hero-dots" id="heroDots">
    <div class="hero-dot active" data-index="0"></div>
    <div class="hero-dot" data-index="1"></div>
    <div class="hero-dot" data-index="2"></div>
    <div class="hero-dot" data-index="3"></div>
    <div class="hero-dot" data-index="4"></div>
  </div>
  <div class="hero-content">
    <div class="hero-pre">Instrumental odontológico profesional</div>
    <h1 class="hero-h">
      Suministro dental<br>
      <em>para profesionales</em>
    </h1>
    <p class="hero-sub">
      Más de 2.500 referencias. Stock en tiempo real sincronizado con SAGE 50.
      Entrega 24/48h para clínicas dentales en toda España.
    </p>
    <div class="hero-ctas">
      <?php
      $shop_url = function_exists('wc_get_page_id') ? get_permalink(wc_get_page_id('shop')) : home_url('/tienda/');
      ?>
      <a href="<?php echo esc_url($shop_url); ?>" class="hero-btn-primary">Ver catálogo completo →</a>
      <?php if (!is_user_logged_in() && function_exists('wc_get_page_permalink')) : ?>
        <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>" class="hero-btn-ghost">Acceso profesional</a>
      <?php endif; ?>
    </div>
  </div>
  <div class="hero-showcase">
    <div class="hero-showcase-inner">
      <?php
      // Mostrar 3 categorías aleatorias con imagen en el showcase lateral
      $showcase_cats = array_slice($wc_cats, 0, 3);
      foreach ($showcase_cats as $cat) :
      ?>
        <a href="<?php echo esc_url($cat['url']); ?>" class="showcase-item">
          <?php if ($cat['image']) : ?>
            <img src="<?php echo esc_url($cat['image']); ?>" alt="<?php echo esc_attr($cat['label']); ?>">
          <?php else : ?>
            <div class="showcase-icon"><?php echo $cat['icon']; ?></div>
          <?php endif; ?>
          <span><?php echo esc_html($cat['label']); ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══ TRUST BAR ════════════════════════════════════════════════ -->
<div class="trust">
  <div class="trust-item">
    <span class="t-icon">🔒</span>
    <div class="t-txt"><strong>Solo profesionales</strong><span>Acceso acreditado B2B</span></div>
  </div>
  <div class="trust-item">
    <span class="t-icon">🚚</span>
    <div class="t-txt"><strong>Envío gratis +<?php echo esc_html(dentix_free_ship()); ?>€</strong><span>Entrega 24/48h Península</span></div>
  </div>
  <div class="trust-item">
    <span class="t-icon">📊</span>
    <div class="t-txt"><strong>Stock en tiempo real</strong><span>Sincronizado con SAGE 50</span></div>
  </div>
  <div class="trust-item">
    <span class="t-icon">↩️</span>
    <div class="t-txt"><strong>Devolución 14 días</strong><span>Garantía según ley española</span></div>
  </div>
  <div class="trust-item">
    <span class="t-icon">📞</span>
    <div class="t-txt"><strong>Soporte técnico</strong><span><?php echo esc_html(dentix_phone()); ?></span></div>
  </div>
</div>

<?php if ($show_cats && !empty($wc_cats)) : ?>
<!-- ═══ ESPECIALIDADES ════════════════════════════════════════════ -->
<section class="sec-cats">
  <div class="sec-header">
    <div class="sec-pre">Catálogo organizado por especialidad</div>
    <h2 class="sec-title">Elige tu especialidad</h2>
    <p class="sec-desc">
      2.500 referencias distribuidas en 8 especialidades odontológicas.
      Todo el catálogo sincronizado con SAGE 50 Cloud en tiempo real.
    </p>
  </div>
  <div class="cats-grid">
    <?php foreach ($wc_cats as $cat) : ?>
      <a href="<?php echo esc_url($cat['url']); ?>" class="cat-card">
        <div class="cat-icon-wrap" style="background:<?php echo esc_attr($cat['color']); ?>">
          <?php if ($cat['image']) : ?>
            <img src="<?php echo esc_url($cat['image']); ?>"
                 alt="<?php echo esc_attr($cat['label']); ?>"
                 class="cat-img">
          <?php else : ?>
            <span class="cat-icon"><?php echo $cat['icon']; ?></span>
          <?php endif; ?>
        </div>
        <div class="cat-info">
          <div class="cat-name"><?php echo esc_html($cat['label']); ?></div>
          <div class="cat-desc"><?php echo esc_html($cat['desc']); ?></div>
          <?php if ($cat['count'] > 0) : ?>
            <div class="cat-count"><?php echo $cat['count']; ?> referencias</div>
          <?php endif; ?>
        </div>
        <div class="cat-arrow">→</div>
      </a>
    <?php endforeach; ?>
  </div>
  <div style="text-align:center;margin-top:40px">
    <a href="<?php echo esc_url(function_exists('wc_get_page_id') ? get_permalink(wc_get_page_id('shop')) : home_url('/tienda/')); ?>"
       class="btn-catalog">
      Ver catálogo completo — todas las referencias
    </a>
  </div>
</section>
<?php endif; ?>

<?php if ($show_featured) :
  $featured = function_exists('wc_get_products') ? wc_get_products([
      'limit'    => 8,
      'featured' => true,
      'status'   => 'publish',
  ]) : [];

  // Si no hay productos destacados, mostrar los más recientes
  if (empty($featured)) {
      $featured = function_exists('wc_get_products') ? wc_get_products([
          'limit'   => 8,
          'status'  => 'publish',
          'orderby' => 'date',
          'order'   => 'DESC',
      ]) : [];
  }
?>

<?php if (!empty($featured)) : ?>
<!-- ═══ PRODUCTOS DESTACADOS ═════════════════════════════════════ -->
<section class="sec-featured">
  <div class="sec-header">
    <div class="sec-pre">Selección Dentix</div>
    <h2 class="sec-title">Productos destacados</h2>
  </div>
  <!-- Filtro por especialidad -->
  <div class="filter-pills">
    <button class="pill on" data-filter="all">Todos</button>
    <?php foreach (array_slice($wc_cats, 0, 6) as $cat) : ?>
      <button class="pill" data-filter="<?php echo esc_attr($cat['slug']); ?>">
        <?php echo esc_html($cat['label']); ?>
      </button>
    <?php endforeach; ?>
  </div>
  <div class="prod-grid" id="featuredGrid">
    <?php foreach ($featured as $product) :
      $img         = get_the_post_thumbnail_url($product->get_id(), 'dentix-product-thumb');
      $sku         = $product->get_sku();
      $on_sale     = $product->is_on_sale();
      $reg_price   = $product->get_regular_price();
      $sale_price  = $product->get_sale_price();
      $brand_terms = wp_get_post_terms($product->get_id(), 'pa_marca');
      $brand       = (!is_wp_error($brand_terms) && !empty($brand_terms)) ? $brand_terms[0]->name : '';
      $cats_terms  = wp_get_post_terms($product->get_id(), 'product_cat');
      $cat_slugs   = !is_wp_error($cats_terms) ? implode(' ', array_column($cats_terms, 'slug')) : '';
    ?>
      <a href="<?php echo esc_url(get_permalink($product->get_id())); ?>"
         class="prod-card" data-cats="<?php echo esc_attr($cat_slugs); ?>">
        <div class="prod-img">
          <?php if ($img) : ?>
            <img src="<?php echo esc_url($img); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" loading="lazy">
          <?php else : ?>
            <div class="prod-circle"><svg class="prod-svg" viewBox="0 0 64 64" fill="none" stroke="var(--gray-mid)" stroke-width="1.5"><rect x="16" y="20" width="32" height="24" rx="3"/><line x1="24" y1="28" x2="40" y2="28"/><line x1="24" y1="34" x2="32" y2="34"/></svg></div>
          <?php endif; ?>
          <button class="p-wish" aria-label="Favorito" onclick="event.preventDefault()">♡</button>
          <?php if ($on_sale && $reg_price) :
            $disc = round((($reg_price - $sale_price) / $reg_price) * 100);
          ?>
            <span class="p-badge sale">−<?php echo $disc; ?>%</span>
          <?php elseif ($product->is_featured()) : ?>
            <span class="p-badge new">Destacado</span>
          <?php endif; ?>
        </div>
        <div class="prod-body">
          <?php if ($brand) : ?><div class="p-brand"><?php echo esc_html($brand); ?></div><?php endif; ?>
          <div class="p-name"><?php echo esc_html($product->get_name()); ?></div>
          <?php if ($sku) : ?><div class="p-ref">REF: <?php echo esc_html($sku); ?></div><?php endif; ?>
          <div class="p-footer">
            <div class="p-price">
              <span class="p-price-main"><?php echo $product->get_price_html(); ?></span>
              <span class="p-price-sub">IVA excl.</span>
            </div>
            <?php if ($product->is_in_stock()) : ?>
              <button class="p-add"
                data-product-id="<?php echo $product->get_id(); ?>"
                onclick="event.preventDefault();dentixAddToCart(<?php echo $product->get_id(); ?>,this)">+</button>
            <?php endif; ?>
          </div>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<script>
// Filtro de especialidades en productos destacados
document.querySelectorAll('.filter-pills .pill').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-pills .pill').forEach(b => b.classList.remove('on'));
    btn.classList.add('on');
    const filter = btn.dataset.filter;
    document.querySelectorAll('#featuredGrid .prod-card').forEach(card => {
      card.style.display = (filter === 'all' || card.dataset.cats.includes(filter)) ? '' : 'none';
    });
  });
});
</script>
<?php endif; ?>
<?php endif; ?>

<!-- ═══ CTA REGISTRO ══════════════════════════════════════════════ -->
<?php if (!is_user_logged_in() && function_exists('wc_get_page_permalink')) : ?>
<section class="sec-cta">
  <div class="cta-inner">
    <div class="cta-left">
      <div class="cta-pre">Acceso exclusivo B2B</div>
      <h2 class="cta-h">¿Eres profesional del sector dental?</h2>
      <p class="cta-sub">
        Solicita tu acceso como profesional y consulta precios, disponibilidad
        y realiza pedidos directamente desde tu cuenta.
      </p>
    </div>
    <div class="cta-right">
      <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>" class="hero-btn-primary" style="display:inline-flex">
        Solicitar acceso profesional →
      </a>
      <div style="font-size:12px;color:rgba(255,255,255,.5);margin-top:10px">
        Ya registrado? <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>" style="color:rgba(255,255,255,.8)">Inicia sesión</a>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php get_footer(); ?>
