<?php
/**
 * Dentix — Página de configuración del tema
 * Accessible en: wp-admin → Apariencia → Dentix
 */
defined('ABSPATH') || exit;

// ── Registrar menú ─────────────────────────────────────────────
add_action('admin_menu', function () {
    add_theme_page(
        'Dentix — Configuración',
        '🦷 Dentix Config',
        'manage_options',
        'dentix-settings',
        'dentix_settings_page'
    );
});

// ── Guardar ajustes ────────────────────────────────────────────
add_action('admin_init', function () {
    register_setting('dentix_settings_group', 'dentix_options', [
        'sanitize_callback' => 'dentix_sanitize_options',
    ]);
});

function dentix_sanitize_options($input): array {
    $clean = [];
    $clean['phone']           = sanitize_text_field($input['phone']          ?? '900 123 456');
    $clean['email']           = sanitize_email($input['email']               ?? 'info@dentix.es');
    $clean['free_shipping']   = absint($input['free_shipping']               ?? 150);
    $clean['footer_desc']     = sanitize_textarea_field($input['footer_desc']?? '');
    $clean['show_hero']       = ! empty($input['show_hero'])  ? 1 : 0;
    $clean['show_cats']       = ! empty($input['show_cats'])  ? 1 : 0;
    $clean['show_featured']   = ! empty($input['show_featured']) ? 1 : 0;
    $clean['cats_in_nav']     = array_map('sanitize_text_field', (array)($input['cats_in_nav'] ?? []));
    return $clean;
}

function dentix_opt(string $key, $default = '') {
    $opts = get_option('dentix_options', []);
    return $opts[$key] ?? $default;
}

// ── Renderizar la página ───────────────────────────────────────
function dentix_settings_page() {
    if (! current_user_can('manage_options')) return;
    $saved = get_option('dentix_options', []);
    ?>
    <div class="wrap">
      <h1>🦷 Dentix — Configuración del tema</h1>
      <p style="color:#666;margin-bottom:24px">
        Ajustes del tema Dentix. Las <strong>categorías de productos</strong> se gestionan en
        <a href="<?php echo admin_url('edit-tags.php?taxonomy=product_cat&post_type=product'); ?>">
          Productos → Categorías →
        </a>
      </p>

      <form method="post" action="options.php">
        <?php settings_fields('dentix_settings_group'); ?>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;max-width:960px">

          <!-- Columna izquierda -->
          <div>
            <div class="postbox" style="padding:20px">
              <h2 style="font-size:14px;margin:0 0 16px;padding-bottom:12px;border-bottom:1px solid #eee">
                📞 Datos de contacto
              </h2>
              <table class="form-table" style="margin:0">
                <tr>
                  <th style="width:140px"><label for="dentix_phone">Teléfono</label></th>
                  <td><input type="text" id="dentix_phone" name="dentix_options[phone]"
                       value="<?php echo esc_attr(dentix_opt('phone','900 123 456')); ?>"
                       class="regular-text"></td>
                </tr>
                <tr>
                  <th><label for="dentix_email">Email contacto</label></th>
                  <td><input type="email" id="dentix_email" name="dentix_options[email]"
                       value="<?php echo esc_attr(dentix_opt('email','info@dentix.es')); ?>"
                       class="regular-text"></td>
                </tr>
                <tr>
                  <th><label for="dentix_free_shipping">Envío gratis (€)</label></th>
                  <td>
                    <input type="number" id="dentix_free_shipping" name="dentix_options[free_shipping]"
                       value="<?php echo esc_attr(dentix_opt('free_shipping', 150)); ?>"
                       class="small-text" min="0" step="5">
                    <p class="description">Pedidos a partir de este importe tendrán envío gratuito</p>
                  </td>
                </tr>
              </table>
            </div>

            <div class="postbox" style="padding:20px;margin-top:16px">
              <h2 style="font-size:14px;margin:0 0 16px;padding-bottom:12px;border-bottom:1px solid #eee">
                🏠 Secciones de la homepage
              </h2>
              <label style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
                <input type="checkbox" name="dentix_options[show_hero]" value="1"
                  <?php checked(dentix_opt('show_hero', 1)); ?>>
                Mostrar carrusel hero
              </label>
              <label style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
                <input type="checkbox" name="dentix_options[show_cats]" value="1"
                  <?php checked(dentix_opt('show_cats', 1)); ?>>
                Mostrar sección de especialidades
              </label>
              <label style="display:flex;align-items:center;gap:8px">
                <input type="checkbox" name="dentix_options[show_featured]" value="1"
                  <?php checked(dentix_opt('show_featured', 1)); ?>>
                Mostrar productos destacados
              </label>
            </div>
          </div>

          <!-- Columna derecha -->
          <div>
            <div class="postbox" style="padding:20px">
              <h2 style="font-size:14px;margin:0 0 8px;padding-bottom:12px;border-bottom:1px solid #eee">
                🗂️ Especialidades en el menú de navegación
              </h2>
              <p class="description" style="margin-bottom:14px">
                Marca las especialidades que aparecen en la barra de navegación superior.<br>
                El orden del menú se gestiona en
                <a href="<?php echo admin_url('nav-menus.php'); ?>">Apariencia → Menús</a>.
              </p>
              <?php
              $cats_in_nav = dentix_opt('cats_in_nav', array_column(dentix_get_categories(), 'slug'));
              foreach (dentix_get_categories() as $cat) :
                $checked = in_array($cat['slug'], (array)$cats_in_nav);
              ?>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
                  <input type="checkbox" name="dentix_options[cats_in_nav][]"
                    value="<?php echo esc_attr($cat['slug']); ?>"
                    <?php checked($checked); ?>>
                  <?php echo $cat['icon']; ?>
                  <strong><?php echo esc_html($cat['label']); ?></strong>
                  <span style="color:#999;font-size:11px">/<?php echo $cat['slug']; ?></span>
                </label>
              <?php endforeach; ?>
            </div>

            <div class="postbox" style="padding:20px;margin-top:16px">
              <h2 style="font-size:14px;margin:0 0 16px;padding-bottom:12px;border-bottom:1px solid #eee">
                📝 Texto del footer
              </h2>
              <textarea name="dentix_options[footer_desc]" rows="3"
                class="large-text" style="font-size:13px"><?php
                echo esc_textarea(dentix_opt('footer_desc',
                  'Distribuidores de instrumental y material odontológico profesional. Más de 2.500 referencias para clínicas dentales y profesionales del sector.'
                ));
              ?></textarea>
            </div>
          </div>
        </div>

        <div style="margin-top:20px">
          <?php submit_button('💾 Guardar configuración', 'primary large'); ?>
        </div>
      </form>

      <hr style="margin:32px 0">

      <h2 style="font-size:14px">🔗 Accesos directos de gestión</h2>
      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <a href="<?php echo admin_url('edit-tags.php?taxonomy=product_cat&post_type=product'); ?>"
           class="button button-secondary">📂 Gestionar categorías</a>
        <a href="<?php echo admin_url('nav-menus.php'); ?>"
           class="button button-secondary">🗺️ Menús de navegación</a>
        <a href="<?php echo admin_url('edit.php?post_type=product'); ?>"
           class="button button-secondary">📦 Todos los productos</a>
        <a href="<?php echo admin_url('edit.php?post_type=product&orderby=date&order=desc'); ?>"
           class="button button-secondary">➕ Añadir producto</a>
        <a href="<?php echo admin_url('admin.php?page=wc-settings'); ?>"
           class="button button-secondary">⚙️ Ajustes WooCommerce</a>
      </div>
    </div>
    <?php
}
