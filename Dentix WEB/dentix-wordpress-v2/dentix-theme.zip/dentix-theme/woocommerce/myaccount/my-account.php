<?php
/**
 * myaccount/my-account.php — Área privada del cliente
 */
defined('ABSPATH') || exit;
get_header();
?>

<?php dentix_breadcrumb(); ?>

<div style="display:grid;grid-template-columns:240px 1fr;gap:32px;padding:48px 60px 80px;max-width:1300px;margin:0 auto">

  <!-- Menú lateral -->
  <aside>
    <div style="background:white;border:1px solid var(--border);border-radius:12px;overflow:hidden">
      <?php
      $current = WC()->query->get_current_endpoint();
      $endpoints = wc_get_account_menu_items();
      foreach ($endpoints as $endpoint => $label) :
        $url    = wc_get_account_endpoint_url($endpoint);
        $active = ($current === $endpoint || ($endpoint === 'dashboard' && !$current));
      ?>
        <a href="<?php echo esc_url($url); ?>"
           style="display:block;padding:14px 20px;font-size:13px;font-weight:<?php echo $active ? '600' : '400'; ?>;
                  color:<?php echo $active ? 'white' : 'var(--dark-main)'; ?>;
                  background:<?php echo $active ? 'var(--dark-main)' : 'transparent'; ?>;
                  border-bottom:1px solid var(--border);
                  text-decoration:none;transition:background .2s"
           <?php if (!$active) echo 'onmouseover="this.style.background=\'var(--gray-light)\'" onmouseout="this.style.background=\'transparent\'"'; ?>>
          <?php echo esc_html($label); ?>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- Info usuario -->
    <div style="margin-top:16px;background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:16px;font-size:12px;color:var(--gray-mid)">
      <?php $user = wp_get_current_user(); ?>
      <div style="font-weight:600;color:var(--dark-main);margin-bottom:4px"><?php echo esc_html($user->display_name); ?></div>
      <div><?php echo esc_html($user->user_email); ?></div>
      <?php
      $nif = get_user_meta($user->ID, 'billing_nif', true);
      if ($nif) echo '<div style="margin-top:4px">NIF/CIF: <strong>' . esc_html($nif) . '</strong></div>';
      ?>
    </div>
  </aside>

  <!-- Contenido principal -->
  <main>
    <?php wc_print_notices(); ?>
    <?php
    /**
     * Renderiza el contenido del endpoint actual.
     * WooCommerce gestiona internamente qué mostrar en cada sección
     * (pedidos, datos personales, direcciones, etc.)
     */
    do_action('woocommerce_account_content');
    ?>
  </main>

</div>

<?php get_footer(); ?>
