# Dentix Sync — Guía de instalación en WordPress / Dinahosting

## Qué es dentix-sync

Es un sistema PHP independiente que sincroniza SAGE 50 Cloud con WooCommerce.
NO es un plugin de WordPress — se instala en el servidor directamente y
se ejecuta mediante cron jobs automáticos.

---

## PASO 1 — Subir los archivos al servidor

### Opción A: Desde el panel de Dinahosting (más fácil)
1. Entra en panel.dinahosting.com
2. Ve a tu dominio → **Administrador de archivos**
3. Navega a la carpeta raíz de tu dominio (donde está WordPress, normalmente `public_html`)
4. Crea una carpeta nueva llamada `dentix-sync`
5. Sube dentro todos los archivos del ZIP `dentix-sync.zip`:
   - `config.php`
   - `sync-catalog.php`
   - `sync-stock.php`
   - `sync-orders.php`
   - Carpeta `src/` con sus 4 archivos PHP
6. Crea las carpetas `logs/` y `cache/` dentro de `dentix-sync/`

### Opción B: Por FTP
1. Conecta con FileZilla o similar usando los datos FTP de Dinahosting
2. Sube la carpeta `dentix-sync/` a la raíz del dominio
3. Crea las carpetas `logs/` y `cache/` con permisos 755

**Ruta final en el servidor:**
```
/public_html/dentix-sync/
  ├── config.php           ← EDITAR CON TUS CREDENCIALES
  ├── sync-catalog.php
  ├── sync-stock.php
  ├── sync-orders.php
  ├── src/
  │   ├── SageClient.php
  │   ├── WooClient.php
  │   ├── Syncer.php
  │   └── Logger.php
  ├── logs/                ← crear vacía
  └── cache/               ← crear vacía
```

---

## PASO 2 — Obtener credenciales de SAGE 50 Cloud

1. Entra en **business.sage.com** con tu cuenta
2. Ve a **Configuración → API / Aplicaciones conectadas**
3. Haz clic en **Crear nueva aplicación**
4. Rellena:
   - Nombre: `Dentix WooCommerce`
   - Tipo: `Client Credentials`
5. Guarda y copia:
   - **Client ID**
   - **Client Secret**
6. El **Subscription ID** aparece en la URL cuando estás en tu empresa:
   `https://app.sageone.com/accounts/`**ESTE_NUMERO**`/...`

---

## PASO 3 — Obtener credenciales de WooCommerce

1. Entra en **wp-admin → WooCommerce → Ajustes**
2. Pestaña **Avanzado** → **API REST**
3. Haz clic en **Añadir clave**
4. Rellena:
   - Descripción: `Dentix Sync`
   - Usuario: tu usuario administrador
   - Permisos: **Lectura/Escritura**
5. Haz clic en **Generar clave API**
6. ⚠️ Copia ahora el **Consumer Key** y **Consumer Secret** — solo se muestran una vez

---

## PASO 4 — Editar config.php

Abre `/public_html/dentix-sync/config.php` con el editor del panel de Dinahosting
y rellena los campos marcados con `← EDITAR`:

```php
'sage' => [
    'client_id'      => 'PEGAR_AQUÍ',   // ← de Paso 2
    'client_secret'  => 'PEGAR_AQUÍ',   // ← de Paso 2
    'subscription_id'=> 'PEGAR_AQUÍ',   // ← de Paso 2
],

'woocommerce' => [
    'store_url'       => 'https://www.dentix.es',  // ← tu dominio real
    'consumer_key'    => 'ck_PEGAR_AQUÍ',          // ← de Paso 3
    'consumer_secret' => 'cs_PEGAR_AQUÍ',          // ← de Paso 3
],

'sync' => [
    'error_email' => 'admin@dentix.es',  // ← tu email
],
```

**Mapeo de categorías** — edita la sección `category_mapping` para que
coincida con los nombres exactos de las familias de tu SAGE:

```php
'category_mapping' => [
    'CIRUGIA'          => 'cirugia',
    'DIAGNOSTICO'      => 'diagnostico',
    'PERIODONCIA'      => 'periodoncia',
    'RESTAURADORA'     => 'restauradora',
    'IMPLANTOLOGIA'    => 'implantologia',
    'ORTODONCIA'       => 'ortodoncia',
    'LABORATORIO'      => 'laboratorio',
    'ACCESORIOS'       => 'accesorios',
    // Añadir aquí los nombres EXACTOS tal como aparecen en SAGE
],
```

---

## PASO 5 — Probar la conexión (modo seguro)

Antes de sincronizar de verdad, activa el modo prueba en config.php:

```php
'dry_run' => true,   // Solo lee, no escribe nada en WooCommerce
```

Luego ejecuta una prueba desde el **Terminal SSH de Dinahosting**
(o desde el panel si tienen consola):

```bash
php /public_html/dentix-sync/sync-catalog.php --dry-run --verbose
```

Verás en pantalla qué productos encontraría en SAGE y qué haría en WooCommerce.
Si todo se ve bien, cambia `dry_run` a `false`.

---

## PASO 6 — Configurar los cron jobs en Dinahosting

1. Entra en panel.dinahosting.com → tu dominio → **Cron Jobs**
2. Añade estos 3 cron jobs:

| Nombre | Comando | Frecuencia |
|--------|---------|------------|
| Dentix — Sync Stock | `php /public_html/dentix-sync/sync-stock.php` | Cada 15 min (`*/15 * * * *`) |
| Dentix — Sync Catálogo | `php /public_html/dentix-sync/sync-catalog.php` | Cada hora (`0 * * * *`) |
| Dentix — Sync Pedidos | `php /public_html/dentix-sync/sync-orders.php` | Cada 5 min (`*/5 * * * *`) |

> ⚠️ Sustituye `/public_html/` por la ruta real de tu dominio en Dinahosting.
> Para saberla, en el administrador de archivos fíjate en la ruta completa.

---

## PASO 7 — Primera sincronización completa

Una vez que los cron estén activos, ejecuta manualmente la primera
sincronización completa (puede tardar 5-15 minutos con 2.500 productos):

```bash
php /public_html/dentix-sync/sync-catalog.php --verbose
```

Cuando termine, ve a **wp-admin → Productos** y verifica que
los artículos han llegado correctamente con sus categorías, precios y stock.

---

## Revisar los logs

Los logs se guardan en `/public_html/dentix-sync/logs/` con un archivo por día.
Puedes verlos desde el Administrador de archivos de Dinahosting.

Si hay errores, se envían automáticamente al email configurado en `config.php`.

---

## Preguntas frecuentes

**¿Se borran los productos de demo al sincronizar con SAGE?**
No automáticamente. Una vez que SAGE sincronice productos con los mismos SKUs,
WooCommerce los actualizará. Los productos de demo que no tengan SKU en SAGE
quedarán en borrador — puedes eliminarlos manualmente.

**¿Qué pasa si falla una sincronización?**
El sistema tiene reintentos automáticos. Si falla, lo intentará en la siguiente
ejecución del cron. El error se registra en los logs y se envía por email.

**¿Puedo pausar la sincronización?**
Sí: desactiva los cron jobs desde el panel de Dinahosting.
También puedes activar `dry_run: true` en config.php para que el cron
se ejecute pero sin escribir en WooCommerce.

---
*Dentix Productos Dentales, S.L. — Guía de instalación Dentix Sync v1.0*
