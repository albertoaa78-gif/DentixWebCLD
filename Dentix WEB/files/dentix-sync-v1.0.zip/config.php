<?php
/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         DENTIX SYNC — ARCHIVO DE CONFIGURACIÓN             ║
 * ║                                                              ║
 * ║  Este es el ÚNICO archivo que necesitas editar.             ║
 * ║  No toques ningún otro archivo salvo que seas técnico.      ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * INSTRUCCIONES RÁPIDAS:
 *   1. Rellena las secciones marcadas con ← EDITAR
 *   2. Guarda el archivo
 *   3. El sincronizador usará esta configuración automáticamente
 */

return [

    // ══════════════════════════════════════════════════════════════
    // 1. SAGE 50 CLOUD — Credenciales de la API
    //    Obtén estos datos en: business.sage.com → Mis aplicaciones
    // ══════════════════════════════════════════════════════════════
    'sage' => [
        'client_id'     => 'TU_CLIENT_ID_AQUI',        // ← EDITAR
        'client_secret' => 'TU_CLIENT_SECRET_AQUI',    // ← EDITAR
        'subscription_id'=> 'TU_SUBSCRIPTION_ID',      // ← EDITAR (ID de tu empresa en Sage)
        'resource_owner_id' => 'TU_RESOURCE_OWNER_ID', // ← EDITAR

        // URL base de la API de Sage Business Cloud
        // España: https://api.columbus.sage.com/es-es/sage200
        // UK/internacional: https://api.columbus.sage.com/uk/sage200
        'api_base_url'  => 'https://api.columbus.sage.com/es-es/sage200',

        // Versión de la API (no cambiar salvo indicación de Sage)
        'api_version'   => 'v1',
    ],

    // ══════════════════════════════════════════════════════════════
    // 2. WOOCOMMERCE — Credenciales de la API REST
    //    Obtén estas claves en: wp-admin → WooCommerce → Ajustes
    //    → Avanzado → API REST → Añadir clave
    // ══════════════════════════════════════════════════════════════
    'woocommerce' => [
        'store_url'     => 'https://www.dentix.es',    // ← EDITAR (tu dominio)
        'consumer_key'  => 'ck_xxxxxxxxxxxxxxxx',      // ← EDITAR
        'consumer_secret'=> 'cs_xxxxxxxxxxxxxxxx',     // ← EDITAR
        'api_version'   => 'wc/v3',
    ],

    // ══════════════════════════════════════════════════════════════
    // 3. SINCRONIZACIÓN — Qué y cuándo sincronizar
    // ══════════════════════════════════════════════════════════════
    'sync' => [

        // ── ¿Qué sincronizar? ──────────────────────────────────
        'products'      => true,   // Sincronizar productos (nombre, desc, precio...)
        'stock'         => true,   // Sincronizar stock en tiempo real
        'categories'    => true,   // Sincronizar categorías
        'images'        => true,   // Sincronizar imágenes de producto
        'orders'        => true,   // Enviar pedidos web → SAGE 50
        'customers'     => true,   // Sincronizar clientes

        // ── ¿Con qué frecuencia? ───────────────────────────────
        // Estas son las frecuencias del cron job (ver INSTRUCCIONES.md)
        'stock_interval_minutes'   => 15,   // Stock: cada 15 min
        'catalog_interval_minutes' => 60,   // Catálogo completo: cada hora
        'orders_interval_minutes'  => 5,    // Pedidos: cada 5 min

        // ── Productos a sincronizar ────────────────────────────
        // Dejar vacío [] para sincronizar TODOS los productos
        // O especificar familias/grupos de SAGE a incluir:
        'sage_product_groups' => [],        // Ej: ['INSTRUMENTAL', 'ENDODONCIA']

        // Familias de SAGE a EXCLUIR (no sincronizar)
        'sage_exclude_groups' => [],        // Ej: ['DESCATALOGADO', 'INTERNO']

        // Solo sincronizar productos activos en SAGE
        'only_active_products' => true,

        // ── Precios ────────────────────────────────────────────
        // Tarifa de SAGE a usar para los precios de la tienda web
        // Opciones típicas: 'price', 'price_band_a', 'price_band_b', 'price_band_c'
        'price_band' => 'price_band_a',     // ← EDITAR: qué tarifa de SAGE usar

        // ¿Los precios de SAGE incluyen IVA?
        'sage_prices_include_vat' => false, // En B2B normalmente false (precio sin IVA)

        // Redondeo de precios (decimales)
        'price_decimals' => 2,

        // ── Lotes / Rendimiento ────────────────────────────────
        // Cuántos productos procesar por llamada a la API (no superar 200)
        'batch_size' => 50,

        // Segundos de pausa entre lotes (para no sobrecargar las APIs)
        'batch_pause_seconds' => 2,

        // ── Modo seguro ────────────────────────────────────────
        // true  → Solo lee de SAGE, no escribe nada en WooCommerce (para pruebas)
        // false → Sincronización real (producción)
        'dry_run' => false,

        // Notificar por email si hay errores
        'error_email'  => 'admin@dentix.es',    // ← EDITAR
        'error_from'   => 'sync@dentix.es',     // ← EDITAR
    ],

    // ══════════════════════════════════════════════════════════════
    // 4. MAPEO DE CAMPOS — Qué campo de SAGE va a qué campo de WooCommerce
    //
    //    FORMATO: 'campo_sage' => 'campo_woocommerce'
    //
    //    Campos disponibles en SAGE 50 Cloud:
    //      code, name, description, search_reference,
    //      commodity_code, barcode, weight, price, price_band_a/b/c,
    //      stock_level, unit_of_measure, product_group_id,
    //      inactive, image_urls[]
    //
    //    Campos disponibles en WooCommerce:
    //      sku, name, description, short_description,
    //      regular_price, stock_quantity, weight,
    //      categories[], images[], meta_data[]
    // ══════════════════════════════════════════════════════════════
    'field_mapping' => [

        // ── Identificación ─────────────────────────────────────
        'sku'               => 'code',          // Código de artículo SAGE → SKU WooCommerce
        'ean'               => 'barcode',       // Código de barras EAN

        // ── Nombre y descripción ───────────────────────────────
        'name'              => 'name',          // Nombre del producto
        'description'       => 'description',   // Descripción larga
        'short_description' => 'search_reference', // Referencia de búsqueda → descripción corta

        // ── Precio ─────────────────────────────────────────────
        // El campo de precio se configura en sync.price_band (sección 3)
        // Aquí puedes configurar si hay precio de oferta en SAGE:
        'sale_price_band'   => '',              // Dejar vacío si no hay precio de oferta

        // ── Stock ──────────────────────────────────────────────
        'stock_quantity'    => 'stock_level',   // Nivel de stock de SAGE

        // ── Medidas ────────────────────────────────────────────
        'weight'            => 'weight',        // Peso del producto

        // ── Categoría ──────────────────────────────────────────
        // La familia de SAGE (product_group) se mapea a categoría WooCommerce
        'category_source'   => 'product_group_id', // Campo de SAGE con la familia/grupo
    ],

    // ══════════════════════════════════════════════════════════════
    // 5. MAPEO DE CATEGORÍAS — Familia SAGE → Categoría WooCommerce
    //
    //    IZQUIERDA: nombre o ID del grupo/familia en SAGE 50
    //    DERECHA:   slug o nombre de la categoría en WooCommerce
    //
    //    Si una familia no aparece aquí, sus productos van a
    //    la categoría "Sin categorizar" de WooCommerce.
    // ══════════════════════════════════════════════════════════════
    'category_mapping' => [
        // Familia SAGE              => Categoría WooCommerce (slug)
        'INSTRUMENTAL'              => 'instrumental',
        'INSTRUMENTAL QUIRURGICO'   => 'instrumental',
        'ENDODONCIA'                => 'endodoncia',
        'ORTODONCIA'                => 'ortodoncia',
        'IMPLANTOLOGIA'             => 'implantologia',
        'IMPLANTES'                 => 'implantologia',
        'MATERIAL CLINICO'          => 'material-clinico',
        'COMPOSITES'                => 'material-clinico',
        'ESTERILIZACION'            => 'esterilizacion',
        'EQUIPAMIENTO'              => 'equipamiento',
        'TURBINAS'                  => 'equipamiento',
        'RADIOLOGIA'                => 'radiologia',
        // ← EDITAR: añadir tus familias reales de SAGE aquí
        // Ejemplo: 'MI_FAMILIA_SAGE' => 'mi-categoria-woo',
    ],

    // ══════════════════════════════════════════════════════════════
    // 6. MAPEO DE IVA — Tipo de artículo SAGE → Clase de IVA WooCommerce
    //
    //    En WooCommerce las clases de IVA son:
    //      ''             → IVA estándar (21%)
    //      'reduced-rate' → IVA reducido (10%)
    //      'zero-rate'    → IVA superreducido (4%) o exento
    // ══════════════════════════════════════════════════════════════
    'vat_mapping' => [
        // Código tipo IVA en SAGE   => Clase de IVA en WooCommerce
        'S1'  => '',               // IVA 21% estándar
        'R1'  => 'reduced-rate',   // IVA 10% reducido
        'SR'  => 'zero-rate',      // IVA 4% superreducido (ej. productos sanitarios)
        'EX'  => 'zero-rate',      // Exento de IVA
        // ← EDITAR: usa los códigos de tipo de IVA reales de tu SAGE
    ],

    // ══════════════════════════════════════════════════════════════
    // 7. MAPEO DE ESTADOS DE PEDIDO
    //    Estado WooCommerce → Estado que se crea en SAGE 50
    // ══════════════════════════════════════════════════════════════
    'order_status_mapping' => [
        // Estado WooCommerce => Acción en SAGE
        'processing' => 'create_sales_order',   // Pedido pagado → Albarán en SAGE
        'completed'  => 'create_invoice',       // Pedido completado → Factura en SAGE
        'cancelled'  => 'cancel_order',         // Cancelado → Cancelar en SAGE
        'refunded'   => 'create_credit_note',   // Reembolsado → Abono en SAGE
    ],

    // ══════════════════════════════════════════════════════════════
    // 8. RUTAS DEL SISTEMA (no cambiar salvo que muevas archivos)
    // ══════════════════════════════════════════════════════════════
    'paths' => [
        'log_dir'   => __DIR__ . '/logs/',
        'cache_dir' => __DIR__ . '/cache/',
        'log_max_days' => 30,       // Borrar logs de más de 30 días
        'cache_ttl_seconds' => 900, // Caché de tokens: 15 min
    ],

];
