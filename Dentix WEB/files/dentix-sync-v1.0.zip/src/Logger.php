<?php
/**
 * Dentix Sync — Logger
 * Escribe logs en archivo y en stdout (para cron jobs)
 */

namespace DentixSync;

class Logger
{
    private string $logFile;
    private bool   $verbose;

    public function __construct(string $logDir, string $context = 'sync', bool $verbose = false)
    {
        if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
        $this->logFile = $logDir . $context . '_' . date('Y-m-d') . '.log';
        $this->verbose = $verbose;
        $this->cleanOldLogs($logDir);
    }

    public function info(string $msg): void    { $this->write('INFO ',  $msg); }
    public function warning(string $msg): void { $this->write('WARN ',  $msg); }
    public function error(string $msg): void   { $this->write('ERROR',  $msg); }
    public function debug(string $msg): void
    {
        if ($this->verbose) $this->write('DEBUG', $msg);
    }

    private function write(string $level, string $msg): void
    {
        $line = sprintf('[%s] [%s] %s', date('H:i:s'), $level, $msg);
        file_put_contents($this->logFile, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
        // También mostrar en consola (útil cuando se ejecuta el cron manualmente)
        echo $line . PHP_EOL;
    }

    public function getLogFile(): string { return $this->logFile; }

    private function cleanOldLogs(string $logDir): void
    {
        // Borrar logs con más de 30 días
        $cutoff = time() - (30 * 86400);
        foreach (glob($logDir . '*.log') as $file) {
            if (filemtime($file) < $cutoff) @unlink($file);
        }
    }
}
