<?php
/**
 * Dentix Sync — Cliente API de SAGE 50 Cloud
 * Gestiona autenticación OAuth2 y todas las llamadas a la API de Sage.
 */

namespace DentixSync;

class SageClient
{
    private array  $cfg;
    private string $accessToken  = '';
    private int    $tokenExpires = 0;
    private string $cacheFile;
    private Logger $log;

    // URL base de OAuth de Sage Business Cloud
    const OAUTH_URL = 'https://oauth.accounting.sage.com/token';

    public function __construct(array $config, Logger $logger)
    {
        $this->cfg       = $config['sage'];
        $this->cacheFile = $config['paths']['cache_dir'] . 'sage_token.json';
        $this->log       = $logger;
    }

    // ══ AUTENTICACIÓN OAuth2 ════════════════════════════════════

    /**
     * Obtiene un access token válido.
     * Lo reutiliza de caché si sigue vigente.
     */
    public function getAccessToken(): string
    {
        // Comprobar si el token cacheado sigue válido (con 60s de margen)
        if ($this->accessToken && time() < ($this->tokenExpires - 60)) {
            return $this->accessToken;
        }

        // Intentar cargar desde caché en disco
        if (file_exists($this->cacheFile)) {
            $cached = json_decode(file_get_contents($this->cacheFile), true);
            if ($cached && $cached['expires_at'] > (time() + 60)) {
                $this->accessToken  = $cached['access_token'];
                $this->tokenExpires = $cached['expires_at'];
                return $this->accessToken;
            }
        }

        // Solicitar nuevo token (Client Credentials flow)
        $this->log->info('Solicitando nuevo token de SAGE 50 Cloud…');

        $response = $this->httpPost(self::OAUTH_URL, [
            'grant_type'    => 'client_credentials',
            'client_id'     => $this->cfg['client_id'],
            'client_secret' => $this->cfg['client_secret'],
            'scope'         => 'readonly',
        ], [], false);

        if (empty($response['access_token'])) {
            throw new \RuntimeException('No se pudo obtener el token de SAGE: ' . json_encode($response));
        }

        $this->accessToken  = $response['access_token'];
        $this->tokenExpires = time() + ($response['expires_in'] ?? 3600);

        // Guardar en caché
        file_put_contents($this->cacheFile, json_encode([
            'access_token' => $this->accessToken,
            'expires_at'   => $this->tokenExpires,
        ]));

        $this->log->info('Token SAGE obtenido. Válido ' . round(($this->tokenExpires - time()) / 60) . ' minutos.');
        return $this->accessToken;
    }

    // ══ PRODUCTOS ═══════════════════════════════════════════════

    /**
     * Obtiene todos los productos de SAGE 50 Cloud (paginados).
     * @return array Lista completa de productos
     */
    public function getProducts(array $filters = []): array
    {
        $this->log->info('Obteniendo productos de SAGE 50 Cloud…');

        $allProducts = [];
        $page = 1;
        $pageSize = 200;

        do {
            $params = array_merge([
                '$page'     => $page,
                '$pageSize' => $pageSize,
            ], $filters);

            $response = $this->apiGet('/products', $params);
            $items    = $response['$items'] ?? $response['items'] ?? $response ?? [];

            if (!is_array($items) || empty($items)) break;

            $allProducts = array_merge($allProducts, $items);
            $this->log->debug("Página {$page}: " . count($items) . " productos obtenidos");

            // Si devuelve menos del tamaño de página, es la última
            $hasMore = count($items) >= $pageSize;
            $page++;

        } while ($hasMore);

        $this->log->info('Total productos obtenidos de SAGE: ' . count($allProducts));
        return $allProducts;
    }

    /**
     * Obtiene un producto concreto de SAGE por su código.
     */
    public function getProduct(string $code): ?array
    {
        try {
            $response = $this->apiGet('/products', ['search' => $code]);
            $items = $response['$items'] ?? $response['items'] ?? [];
            foreach ($items as $item) {
                if (($item['code'] ?? '') === $code) return $item;
            }
            return null;
        } catch (\Exception $e) {
            $this->log->warning("Producto {$code} no encontrado en SAGE: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Obtiene el nivel de stock de un producto.
     */
    public function getStockLevel(string $productId): ?float
    {
        try {
            $response = $this->apiGet("/products/{$productId}/stock_levels");
            $items = $response['$items'] ?? $response['items'] ?? [];
            $total = 0;
            foreach ($items as $item) {
                // Sumar stock de todos los almacenes
                $total += (float)($item['quantity_in_stock'] ?? $item['stock_level'] ?? 0);
            }
            return $total;
        } catch (\Exception $e) {
            $this->log->warning("Error obteniendo stock de {$productId}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Obtiene los niveles de stock de múltiples productos a la vez.
     * Más eficiente que llamar uno por uno.
     */
    public function getStockLevels(array $productIds = []): array
    {
        try {
            $response = $this->apiGet('/stock_levels', ['$pageSize' => 200]);
            $items    = $response['$items'] ?? $response['items'] ?? [];

            $stockMap = [];
            foreach ($items as $item) {
                $id = $item['product']['id'] ?? $item['product_id'] ?? null;
                if (!$id) continue;
                $stockMap[$id] = ($stockMap[$id] ?? 0) + (float)($item['quantity_in_stock'] ?? 0);
            }
            return $stockMap;
        } catch (\Exception $e) {
            $this->log->warning('Error obteniendo stock masivo: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Obtiene los grupos/familias de productos.
     */
    public function getProductGroups(): array
    {
        try {
            $response = $this->apiGet('/product_groups', ['$pageSize' => 200]);
            $items    = $response['$items'] ?? $response['items'] ?? [];
            // Indexar por ID para búsqueda rápida
            $groups = [];
            foreach ($items as $g) {
                $groups[$g['id']] = $g;
            }
            return $groups;
        } catch (\Exception $e) {
            $this->log->warning('Error obteniendo grupos de productos: ' . $e->getMessage());
            return [];
        }
    }

    // ══ PEDIDOS ══════════════════════════════════════════════════

    /**
     * Crea un albarán/pedido de venta en SAGE desde un pedido de WooCommerce.
     */
    public function createSalesOrder(array $wcOrder): array
    {
        $this->log->info("Creando albarán en SAGE para pedido WC #{$wcOrder['id']}…");

        $sageOrder = $this->mapWcOrderToSage($wcOrder);

        try {
            $result = $this->apiPost('/sales_orders', $sageOrder);
            $this->log->info("Albarán SAGE creado: " . ($result['id'] ?? 'OK'));
            return $result;
        } catch (\Exception $e) {
            $this->log->error("Error creando albarán SAGE: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Crea una factura en SAGE.
     */
    public function createInvoice(array $wcOrder): array
    {
        $this->log->info("Creando factura en SAGE para pedido WC #{$wcOrder['id']}…");

        $sageInvoice = $this->mapWcOrderToSage($wcOrder, 'invoice');

        try {
            $result = $this->apiPost('/sales_invoices', $sageInvoice);
            $this->log->info("Factura SAGE creada: " . ($result['id'] ?? 'OK'));
            return $result;
        } catch (\Exception $e) {
            $this->log->error("Error creando factura SAGE: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Busca o crea un cliente en SAGE.
     */
    public function findOrCreateCustomer(array $wcOrder): ?array
    {
        $email = $wcOrder['billing']['email'] ?? '';
        $nif   = $wcOrder['meta_data_map']['_billing_nif'] ?? '';

        // Buscar por NIF primero (identificador fiscal más fiable)
        if ($nif) {
            $response = $this->apiGet('/customers', ['search' => $nif]);
            $items = $response['$items'] ?? $response['items'] ?? [];
            if (!empty($items)) return $items[0];
        }

        // Buscar por email
        if ($email) {
            $response = $this->apiGet('/customers', ['search' => $email]);
            $items = $response['$items'] ?? $response['items'] ?? [];
            foreach ($items as $c) {
                if (($c['email'] ?? '') === $email) return $c;
            }
        }

        // Crear cliente nuevo en SAGE
        $this->log->info("Cliente no existe en SAGE, creando: {$email}");
        try {
            return $this->apiPost('/customers', $this->mapWcCustomerToSage($wcOrder));
        } catch (\Exception $e) {
            $this->log->warning("No se pudo crear cliente en SAGE: " . $e->getMessage());
            return null;
        }
    }

    // ══ MAPEOS INTERNOS ══════════════════════════════════════════

    /**
     * Convierte un pedido WooCommerce al formato esperado por la API de SAGE.
     */
    private function mapWcOrderToSage(array $order, string $type = 'order'): array
    {
        $billing = $order['billing'] ?? [];
        $lines   = [];

        foreach ($order['line_items'] ?? [] as $item) {
            $lines[] = [
                'product'    => ['code' => $item['sku'] ?? ''],
                'quantity'   => $item['quantity'],
                'unit_price' => round((float)$item['price'], 2),
                'description'=> $item['name'],
            ];
        }

        // Línea de envío si existe
        foreach ($order['shipping_lines'] ?? [] as $ship) {
            if ((float)($ship['total'] ?? 0) > 0) {
                $lines[] = [
                    'description' => 'Gastos de envío: ' . $ship['method_title'],
                    'unit_price'  => round((float)$ship['total'], 2),
                    'quantity'    => 1,
                    'product'     => ['code' => 'ENVIO'],
                ];
            }
        }

        $result = [
            'customer'      => ['reference' => $billing['email'] ?? ''],
            'reference'     => 'WEB-' . $order['id'],
            'date'          => substr($order['date_created'] ?? date('c'), 0, 10),
            'shipping_address' => [
                'name'       => trim(($order['shipping']['first_name'] ?? $billing['first_name'] ?? '') . ' ' . ($order['shipping']['last_name'] ?? $billing['last_name'] ?? '')),
                'address_1'  => $order['shipping']['address_1'] ?? $billing['address_1'] ?? '',
                'city'       => $order['shipping']['city'] ?? $billing['city'] ?? '',
                'postcode'   => $order['shipping']['postcode'] ?? $billing['postcode'] ?? '',
                'country'    => $order['shipping']['country'] ?? $billing['country'] ?? 'ES',
            ],
            'lines'         => $lines,
            'notes'         => 'Pedido web Dentix #' . $order['id'] . '. Método de pago: ' . ($order['payment_method_title'] ?? ''),
        ];

        return $result;
    }

    private function mapWcCustomerToSage(array $order): array
    {
        $billing = $order['billing'] ?? [];
        $nif     = $order['meta_data_map']['_billing_nif'] ?? '';

        return [
            'name'      => $billing['company'] ?: trim(($billing['first_name'] ?? '') . ' ' . ($billing['last_name'] ?? '')),
            'email'     => $billing['email'] ?? '',
            'telephone' => $billing['phone'] ?? '',
            'tax_number'=> $nif,
            'address'   => [
                'address_1' => $billing['address_1'] ?? '',
                'city'      => $billing['city'] ?? '',
                'postcode'  => $billing['postcode'] ?? '',
                'country'   => ['code' => $billing['country'] ?? 'ES'],
            ],
        ];
    }

    // ══ HTTP — Métodos de bajo nivel ═════════════════════════════

    private function apiGet(string $endpoint, array $params = []): array
    {
        $base    = rtrim($this->cfg['api_base_url'], '/');
        $version = $this->cfg['api_version'];
        $url     = "{$base}/{$version}{$endpoint}";
        if ($params) $url .= '?' . http_build_query($params);

        return $this->httpGet($url);
    }

    private function apiPost(string $endpoint, array $data): array
    {
        $base    = rtrim($this->cfg['api_base_url'], '/');
        $version = $this->cfg['api_version'];
        $url     = "{$base}/{$version}{$endpoint}";

        return $this->httpPost($url, $data, $this->authHeaders());
    }

    private function httpGet(string $url, array $headers = []): array
    {
        $headers = array_merge($this->authHeaders(), $headers);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => $this->buildHeaders($headers),
        ]);

        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($err) throw new \RuntimeException("cURL error en GET {$url}: {$err}");
        if ($code >= 400) {
            $this->log->error("SAGE API error {$code} en GET {$url}: {$body}");
            throw new \RuntimeException("SAGE API error {$code}: {$body}");
        }

        return json_decode($body, true) ?? [];
    }

    private function httpPost(string $url, array $data, array $headers = [], bool $json = true): array
    {
        $ch = curl_init($url);
        $postData = $json ? json_encode($data) : http_build_query($data);
        if ($json) $headers['Content-Type'] = 'application/json';

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $postData,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => $this->buildHeaders($headers),
        ]);

        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($err) throw new \RuntimeException("cURL error en POST {$url}: {$err}");
        if ($code >= 400) {
            $this->log->error("SAGE API error {$code} en POST {$url}: {$body}");
            throw new \RuntimeException("SAGE API error {$code}: {$body}");
        }

        return json_decode($body, true) ?? [];
    }

    private function authHeaders(): array
    {
        return [
            'Authorization' => 'Bearer ' . $this->getAccessToken(),
            'X-Site'        => $this->cfg['subscription_id'] ?? '',
        ];
    }

    private function buildHeaders(array $headers): array
    {
        $result = [];
        foreach ($headers as $key => $val) {
            $result[] = is_int($key) ? $val : "{$key}: {$val}";
        }
        return $result;
    }
}
