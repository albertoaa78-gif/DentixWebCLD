<?php
/**
 * Dentix Sync — Motor de sincronización
 * Orquesta la sincronización SAGE 50 Cloud ↔ WooCommerce
 */

namespace DentixSync;

class Syncer
{
    private SageClient $sage;
    private WooClient  $woo;
    private Logger     $log;
    private array      $cfg;
    private bool       $dryRun;

    // Contadores para el informe final
    private int $created  = 0;
    private int $updated  = 0;
    private int $skipped  = 0;
    private int $errors   = 0;
    private int $orders   = 0;

    public function __construct(array $config, Logger $logger)
    {
        $this->cfg    = $config;
        $this->log    = $logger;
        $this->dryRun = $config['sync']['dry_run'] ?? false;
        $this->sage   = new SageClient($config, $logger);
        $this->woo    = new WooClient($config, $logger);

        if ($this->dryRun) {
            $this->log->warning('⚠️  MODO DRY RUN ACTIVO — No se escribirá nada en WooCommerce');
        }
    }

    // ══════════════════════════════════════════════════════════════
    // SINCRONIZACIÓN COMPLETA DE CATÁLOGO
    // Llama esto desde el cron job horario
    // ══════════════════════════════════════════════════════════════
    public function syncCatalog(): void
    {
        $start = microtime(true);
        $this->log->info('═══ INICIO SINCRONIZACIÓN CATÁLOGO ═══');
        $this->resetCounters();

        try {
            // 1. Cargar grupos/familias de SAGE (para mapeo de categorías)
            $sageGroups = $this->sage->getProductGroups();
            $this->log->info('Grupos SAGE cargados: ' . count($sageGroups));

            // 2. Cargar categorías existentes en WooCommerce
            $wooCategories = $this->woo->getCategoriesIndexedBySlug();

            // 3. Obtener productos de SAGE (con filtros de config si los hay)
            $sageFilters = [];
            $excludeGroups = $this->cfg['sync']['sage_exclude_groups'] ?? [];
            if ($this->cfg['sync']['only_active_products'] ?? true) {
                $sageFilters['active'] = true;
            }
            $sageProducts = $this->sage->getProducts($sageFilters);

            // 4. Obtener índice de productos de WooCommerce (SKU → producto)
            $wooProducts = $this->woo->getAllProductsIndexedBySku();

            // 5. Procesar en lotes
            $batchSize = $this->cfg['sync']['batch_size'] ?? 50;
            $pause     = $this->cfg['sync']['batch_pause_seconds'] ?? 2;
            $batches   = array_chunk($sageProducts, $batchSize);
            $total     = count($sageProducts);

            $this->log->info("Procesando {$total} productos en " . count($batches) . " lotes de {$batchSize}…");

            foreach ($batches as $i => $batch) {
                $this->log->info(sprintf('Lote %d/%d…', $i + 1, count($batches)));
                $this->processBatch($batch, $wooProducts, $sageGroups, $wooCategories);
                if ($i < count($batches) - 1) sleep($pause);
            }

        } catch (\Exception $e) {
            $this->log->error('Error fatal en sincronización de catálogo: ' . $e->getMessage());
            $this->errors++;
        }

        $elapsed = round(microtime(true) - $start, 1);
        $this->logSummary('CATÁLOGO', $elapsed);
    }

    // ══════════════════════════════════════════════════════════════
    // SINCRONIZACIÓN DE STOCK (rápida — solo stock)
    // Llama esto desde el cron job cada 15 minutos
    // ══════════════════════════════════════════════════════════════
    public function syncStock(): void
    {
        $start = microtime(true);
        $this->log->info('─── Inicio sync stock ───');
        $this->resetCounters();

        try {
            // Obtener stock actualizado de SAGE
            $sageStockMap = $this->sage->getStockLevels(); // productId SAGE => cantidad

            if (empty($sageStockMap)) {
                $this->log->warning('SAGE devolvió stock vacío. Abortando sync de stock.');
                return;
            }

            // Obtener productos de SAGE para cruzar productId con SKU
            $sageProducts = $this->sage->getProducts();
            $skuStockMap  = []; // SKU => cantidad

            foreach ($sageProducts as $sp) {
                $sku = $sp['code'] ?? '';
                $id  = $sp['id']   ?? '';
                if ($sku && $id && isset($sageStockMap[$id])) {
                    $skuStockMap[$sku] = (int)$sageStockMap[$id];
                }
            }

            // Obtener productos de WooCommerce y actualizar stock
            $wooProducts = $this->woo->getAllProductsIndexedBySku();
            $stockUpdates = []; // wooProductId => newQuantity

            foreach ($skuStockMap as $sku => $qty) {
                if (isset($wooProducts[$sku])) {
                    $wooId    = $wooProducts[$sku]['id'];
                    $currentQ = $wooProducts[$sku]['stock_quantity'] ?? -1;

                    if ((int)$currentQ !== $qty) {
                        $stockUpdates[$wooId] = $qty;
                        $this->updated++;
                        $this->log->debug("Stock {$sku}: {$currentQ} → {$qty}");
                    } else {
                        $this->skipped++;
                    }
                }
            }

            // Aplicar actualizaciones en lote
            if (!empty($stockUpdates) && !$this->dryRun) {
                $this->woo->batchUpdateStock($stockUpdates);
                $this->log->info('Stock actualizado: ' . count($stockUpdates) . ' productos');
            } elseif ($this->dryRun && !empty($stockUpdates)) {
                $this->log->info('[DRY RUN] Se actualizarían: ' . count($stockUpdates) . ' stocks');
            }

        } catch (\Exception $e) {
            $this->log->error('Error en sync de stock: ' . $e->getMessage());
            $this->errors++;
        }

        $elapsed = round(microtime(true) - $start, 1);
        $this->logSummary('STOCK', $elapsed);
    }

    // ══════════════════════════════════════════════════════════════
    // SINCRONIZACIÓN DE PEDIDOS (WooCommerce → SAGE)
    // Llama esto desde el cron job cada 5 minutos
    // ══════════════════════════════════════════════════════════════
    public function syncOrders(): void
    {
        $start = microtime(true);
        $this->log->info('─── Inicio sync pedidos ───');
        $this->resetCounters();

        try {
            $statusMap = $this->cfg['order_status_mapping'];

            foreach ($statusMap as $wcStatus => $sageAction) {
                $orders = $this->woo->getPendingOrders($wcStatus);

                foreach ($orders as $order) {
                    // Saltarse pedidos ya enviados a SAGE
                    $metaMap = $this->buildMetaMap($order['meta_data'] ?? []);
                    if (!empty($metaMap['_sage_order_id'])) {
                        $this->skipped++;
                        continue;
                    }

                    $order['meta_data_map'] = $metaMap;

                    try {
                        $sageResult = $this->processOrderToSage($order, $sageAction);

                        if ($sageResult && !$this->dryRun) {
                            // Guardar el ID de SAGE en el pedido de WooCommerce
                            $sageId = $sageResult['id'] ?? '';
                            $this->woo->setOrderMeta($order['id'], '_sage_order_id', $sageId);
                            $this->woo->addOrderNote(
                                $order['id'],
                                "✅ Enviado a SAGE 50. Referencia SAGE: {$sageId}"
                            );
                            $this->orders++;
                            $this->log->info("Pedido WC #{$order['id']} → SAGE {$sageId}");
                        }

                    } catch (\Exception $e) {
                        $this->errors++;
                        $this->log->error("Error procesando pedido #{$order['id']}: " . $e->getMessage());
                        if (!$this->dryRun) {
                            $this->woo->addOrderNote(
                                $order['id'],
                                "❌ Error al enviar a SAGE: " . $e->getMessage()
                            );
                        }
                    }
                }
            }

        } catch (\Exception $e) {
            $this->log->error('Error fatal en sync de pedidos: ' . $e->getMessage());
            $this->errors++;
        }

        $elapsed = round(microtime(true) - $start, 1);
        $this->logSummary('PEDIDOS', $elapsed);
    }

    // ══════════════════════════════════════════════════════════════
    // PROCESAMIENTO INTERNO
    // ══════════════════════════════════════════════════════════════

    private function processBatch(
        array $sageProducts,
        array &$wooProducts,
        array $sageGroups,
        array &$wooCategories
    ): void {
        $toCreate = [];
        $toUpdate = [];

        foreach ($sageProducts as $sp) {
            try {
                // Filtrar por grupos excluidos
                $groupId   = $sp['product_group']['id'] ?? $sp['product_group_id'] ?? '';
                $groupName = $sageGroups[$groupId]['name'] ?? '';
                $excludes  = array_map('strtoupper', $this->cfg['sync']['sage_exclude_groups'] ?? []);

                if ($groupName && in_array(strtoupper($groupName), $excludes)) {
                    $this->skipped++;
                    continue;
                }

                // Mapear producto SAGE → WooCommerce
                $wooData = $this->mapSageProductToWoo($sp, $sageGroups, $wooCategories);

                if (!$wooData) {
                    $this->skipped++;
                    continue;
                }

                $sku = $wooData['sku'];

                if (isset($wooProducts[$sku])) {
                    // Producto existe → actualizar
                    $existing = $wooProducts[$sku];
                    if ($this->hasChanges($existing, $wooData)) {
                        $wooData['id'] = $existing['id'];
                        $toUpdate[]    = $wooData;
                    } else {
                        $this->skipped++;
                    }
                } else {
                    // Producto nuevo → crear
                    $toCreate[] = $wooData;
                }

            } catch (\Exception $e) {
                $this->log->warning("Error mapeando producto SKU '{$sp['code']}': " . $e->getMessage());
                $this->errors++;
            }
        }

        // Enviar lote a WooCommerce
        if (!$this->dryRun && (!empty($toCreate) || !empty($toUpdate))) {
            try {
                $result = $this->woo->batchProducts($toCreate, $toUpdate);
                $this->created += count($result['create'] ?? $toCreate);
                $this->updated += count($result['update'] ?? $toUpdate);

                // Actualizar índice local con nuevos productos
                foreach ($result['create'] ?? [] as $p) {
                    if (!empty($p['sku'])) $wooProducts[$p['sku']] = $p;
                }
            } catch (\Exception $e) {
                $this->log->error('Error en batch WooCommerce: ' . $e->getMessage());
                $this->errors += count($toCreate) + count($toUpdate);
            }
        } else {
            if ($this->dryRun) {
                $this->created += count($toCreate);
                $this->updated += count($toUpdate);
                $this->log->info("[DRY RUN] Crearía: {$this->created}, Actualizaría: {$this->updated}");
            }
        }
    }

    /**
     * Mapea un producto de SAGE al formato de WooCommerce.
     */
    private function mapSageProductToWoo(array $sp, array $groups, array &$wooCategories): ?array
    {
        $fieldMap  = $this->cfg['field_mapping'];
        $syncCfg   = $this->cfg['sync'];
        $catMap    = $this->cfg['category_mapping'];
        $vatMap    = $this->cfg['vat_mapping'];

        $sku = trim($sp[$fieldMap['sku']] ?? $sp['code'] ?? '');
        if (!$sku) return null; // Sin SKU no se puede sincronizar

        // ── Precio ──────────────────────────────────────────────
        $priceBand   = $syncCfg['price_band'] ?? 'price';
        $regularPrice = (float)($sp[$priceBand] ?? $sp['price'] ?? 0);
        if ($regularPrice <= 0) return null; // Producto sin precio no va a la tienda

        $salePrice = '';
        if (!empty($fieldMap['sale_price_band']) && isset($sp[$fieldMap['sale_price_band']])) {
            $sale = (float)$sp[$fieldMap['sale_price_band']];
            if ($sale > 0 && $sale < $regularPrice) {
                $salePrice = (string)round($sale, 2);
            }
        }

        // ── Categoría ───────────────────────────────────────────
        $groupId   = $sp['product_group']['id'] ?? $sp['product_group_id'] ?? '';
        $groupName = $groups[$groupId]['name'] ?? '';
        $wooSlug   = $catMap[strtoupper($groupName)] ?? null;
        $categories = [];

        if ($wooSlug && isset($wooCategories[$wooSlug])) {
            $categories[] = ['id' => $wooCategories[$wooSlug]['id']];
        } elseif ($wooSlug) {
            // Crear categoría si no existe
            try {
                $newCat = $this->woo->createCategory($groupName, $wooSlug);
                $wooCategories[$wooSlug] = $newCat;
                $categories[] = ['id' => $newCat['id']];
                $this->log->info("Categoría creada en WooCommerce: {$groupName} ({$wooSlug})");
            } catch (\Exception $e) {
                $this->log->warning("No se pudo crear categoría {$groupName}: " . $e->getMessage());
            }
        }

        // ── Clase de IVA ────────────────────────────────────────
        $vatCode  = $sp['tax_code']['id'] ?? $sp['vat_rate'] ?? '';
        $taxClass = $vatMap[$vatCode] ?? ''; // '' = IVA estándar (21%)

        // ── Stock ────────────────────────────────────────────────
        $stockQty = (int)($sp[$fieldMap['stock_quantity']] ?? $sp['stock_level'] ?? 0);

        // ── Descripción ─────────────────────────────────────────
        $description = $sp[$fieldMap['description']] ?? $sp['description'] ?? '';
        $shortDesc   = $sp[$fieldMap['short_description']] ?? $sp['search_reference'] ?? '';

        // ── Imagen ──────────────────────────────────────────────
        $images = [];
        if ($syncCfg['images'] ?? true) {
            $imgUrls = $sp['image_urls'] ?? $sp['images'] ?? [];
            foreach ((array)$imgUrls as $url) {
                if (filter_var($url, FILTER_VALIDATE_URL)) {
                    $images[] = ['src' => $url];
                }
            }
        }

        // ── Meta data (campos extra para el tema Dentix) ────────
        $metaData = [
            ['key' => '_sage_product_id',  'value' => $sp['id']   ?? ''],
            ['key' => '_sage_group_id',    'value' => $groupId],
            ['key' => '_sage_group_name',  'value' => $groupName],
            ['key' => '_last_sage_sync',   'value' => date('c')],
        ];

        // EAN / Código de barras
        $ean = $sp[$fieldMap['ean']] ?? $sp['barcode'] ?? '';
        if ($ean) $metaData[] = ['key' => '_ean', 'value' => $ean];

        // ── Construir array WooCommerce ──────────────────────────
        $wooProduct = [
            'name'              => $sp[$fieldMap['name']] ?? $sp['name'] ?? $sku,
            'sku'               => $sku,
            'type'              => 'simple',
            'status'            => ($sp['inactive'] ?? false) ? 'draft' : 'publish',
            'regular_price'     => (string)round($regularPrice, 2),
            'description'       => $description,
            'short_description' => $shortDesc,
            'manage_stock'      => true,
            'stock_quantity'    => $stockQty,
            'stock_status'      => $stockQty > 0 ? 'instock' : 'outofstock',
            'tax_class'         => $taxClass,
            'meta_data'         => $metaData,
        ];

        if ($salePrice)         $wooProduct['sale_price']  = $salePrice;
        if (!empty($categories)) $wooProduct['categories'] = $categories;
        if (!empty($images))    $wooProduct['images']      = $images;

        $weight = $sp[$fieldMap['weight']] ?? '';
        if ($weight) $wooProduct['weight'] = (string)$weight;

        return $wooProduct;
    }

    private function processOrderToSage(array $order, string $action): ?array
    {
        // Buscar o crear cliente en SAGE
        $customer = $this->sage->findOrCreateCustomer($order);

        switch ($action) {
            case 'create_sales_order':
                return $this->sage->createSalesOrder($order);
            case 'create_invoice':
                return $this->sage->createInvoice($order);
            case 'cancel_order':
                $this->log->info("Pedido #{$order['id']} cancelado — registrar manualmente en SAGE si necesario");
                return ['id' => 'cancelled'];
            case 'create_credit_note':
                $this->log->info("Pedido #{$order['id']} reembolsado — crear abono manualmente en SAGE");
                return ['id' => 'refunded'];
            default:
                return null;
        }
    }

    // ══ UTILIDADES ══════════════════════════════════════════════

    /**
     * Comprueba si los datos de SAGE difieren de lo que hay en WooCommerce.
     * Solo actualiza si hay cambios reales (evita escrituras innecesarias).
     */
    private function hasChanges(array $existing, array $new): bool
    {
        $fieldsToCheck = ['regular_price', 'stock_quantity', 'status', 'name', 'description'];
        foreach ($fieldsToCheck as $field) {
            if (!isset($new[$field])) continue;
            $existingVal = (string)($existing[$field] ?? '');
            $newVal      = (string)$new[$field];
            if ($existingVal !== $newVal) return true;
        }
        return false;
    }

    private function buildMetaMap(array $metaData): array
    {
        $map = [];
        foreach ($metaData as $m) {
            $map[$m['key']] = $m['value'];
        }
        return $map;
    }

    private function resetCounters(): void
    {
        $this->created = $this->updated = $this->skipped = $this->errors = $this->orders = 0;
    }

    private function logSummary(string $type, float $elapsed): void
    {
        $this->log->info(sprintf(
            '═══ FIN SYNC %s — %.1fs | ✅ Creados: %d | 🔄 Actualizados: %d | ⏭ Sin cambios: %d | 📦 Pedidos: %d | ❌ Errores: %d',
            $type, $elapsed,
            $this->created, $this->updated, $this->skipped, $this->orders, $this->errors
        ));

        // Enviar email de alerta si hay errores
        if ($this->errors > 0 && !empty($this->cfg['sync']['error_email'])) {
            $this->sendErrorAlert($type);
        }
    }

    private function sendErrorAlert(string $type): void
    {
        $to      = $this->cfg['sync']['error_email'];
        $from    = $this->cfg['sync']['error_from'] ?? $to;
        $subject = "[Dentix Sync] ❌ Errores en sync {$type} — " . date('d/m/Y H:i');
        $body    = "Se han producido {$this->errors} errores en la sincronización {$type}.\n\n"
                 . "Revisa los logs en: " . $this->cfg['paths']['log_dir'] . "\n\n"
                 . "Fecha: " . date('d/m/Y H:i:s') . "\n";

        @mail($to, $subject, $body, "From: {$from}\r\nContent-Type: text/plain; charset=utf-8");
    }
}
