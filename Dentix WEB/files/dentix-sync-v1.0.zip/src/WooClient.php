<?php
/**
 * Dentix Sync — Cliente API REST de WooCommerce
 */

namespace DentixSync;

class WooClient
{
    private array  $cfg;
    private Logger $log;
    private string $baseUrl;

    public function __construct(array $config, Logger $logger)
    {
        $this->cfg     = $config['woocommerce'];
        $this->log     = $logger;
        $this->baseUrl = rtrim($this->cfg['store_url'], '/') . '/wp-json/' . $this->cfg['api_version'];
    }

    // ══ PRODUCTOS ═══════════════════════════════════════════════

    /**
     * Obtiene un producto de WooCommerce por su SKU.
     */
    public function getProductBySku(string $sku): ?array
    {
        $results = $this->get('/products', ['sku' => $sku, 'per_page' => 1]);
        return !empty($results) ? $results[0] : null;
    }

    /**
     * Obtiene todos los productos de WooCommerce (paginados).
     * Devuelve un mapa SKU => producto para búsqueda rápida.
     */
    public function getAllProductsIndexedBySku(): array
    {
        $this->log->info('Indexando productos existentes en WooCommerce…');
        $allProducts = [];
        $page = 1;

        do {
            $batch = $this->get('/products', ['per_page' => 100, 'page' => $page, 'status' => 'any']);
            if (empty($batch)) break;
            foreach ($batch as $p) {
                if (!empty($p['sku'])) {
                    $allProducts[$p['sku']] = $p;
                }
            }
            $page++;
        } while (count($batch) >= 100);

        $this->log->info('Productos WooCommerce indexados: ' . count($allProducts));
        return $allProducts;
    }

    /**
     * Crea un producto nuevo en WooCommerce.
     */
    public function createProduct(array $data): array
    {
        $this->log->debug("Creando producto: {$data['sku']} — {$data['name']}");
        return $this->post('/products', $data);
    }

    /**
     * Actualiza un producto existente en WooCommerce.
     */
    public function updateProduct(int $productId, array $data): array
    {
        $this->log->debug("Actualizando producto ID {$productId}: {$data['sku']}");
        return $this->put("/products/{$productId}", $data);
    }

    /**
     * Crea o actualiza en lote (más eficiente — una llamada API para varios productos).
     * @param array $create Productos a crear
     * @param array $update Productos a actualizar
     */
    public function batchProducts(array $create, array $update): array
    {
        if (empty($create) && empty($update)) return [];

        $payload = [];
        if (!empty($create)) $payload['create'] = $create;
        if (!empty($update)) $payload['update'] = $update;

        $this->log->info(sprintf(
            'Batch WooCommerce: %d a crear, %d a actualizar',
            count($create),
            count($update)
        ));

        return $this->post('/products/batch', $payload);
    }

    /**
     * Actualiza solo el stock de un producto (llamada ligera).
     */
    public function updateStock(int $productId, int $quantity): array
    {
        return $this->put("/products/{$productId}", [
            'stock_quantity' => $quantity,
            'manage_stock'   => true,
        ]);
    }

    /**
     * Actualiza el stock de varios productos en lote.
     * @param array $stocks [product_id => quantity]
     */
    public function batchUpdateStock(array $stocks): void
    {
        if (empty($stocks)) return;

        $updates = [];
        foreach ($stocks as $productId => $quantity) {
            $updates[] = [
                'id'             => $productId,
                'stock_quantity' => (int)$quantity,
                'manage_stock'   => true,
            ];
        }

        // WooCommerce batch acepta hasta 100 por llamada
        foreach (array_chunk($updates, 100) as $chunk) {
            $this->post('/products/batch', ['update' => $chunk]);
        }
    }

    // ══ CATEGORÍAS ═══════════════════════════════════════════════

    /**
     * Obtiene todas las categorías de WooCommerce indexadas por slug.
     */
    public function getCategoriesIndexedBySlug(): array
    {
        $cats = $this->get('/products/categories', ['per_page' => 100, 'hide_empty' => false]);
        $indexed = [];
        foreach ($cats as $cat) {
            $indexed[$cat['slug']] = $cat;
            $indexed[strtolower($cat['name'])] = $cat;
        }
        return $indexed;
    }

    /**
     * Crea una categoría nueva.
     */
    public function createCategory(string $name, string $slug = '', int $parentId = 0): array
    {
        $data = ['name' => $name];
        if ($slug)     $data['slug']   = $slug;
        if ($parentId) $data['parent'] = $parentId;
        return $this->post('/products/categories', $data);
    }

    // ══ PEDIDOS ══════════════════════════════════════════════════

    /**
     * Obtiene pedidos de WooCommerce pendientes de enviar a SAGE.
     */
    public function getPendingOrders(string $status = 'processing'): array
    {
        return $this->get('/orders', [
            'status'   => $status,
            'per_page' => 100,
        ]);
    }

    /**
     * Obtiene pedidos creados/actualizados después de una fecha.
     */
    public function getOrdersSince(string $dateTimeISO): array
    {
        return $this->get('/orders', [
            'after'    => $dateTimeISO,
            'per_page' => 100,
            'orderby'  => 'date',
            'order'    => 'asc',
        ]);
    }

    /**
     * Añade una nota privada a un pedido (visible solo en wp-admin).
     */
    public function addOrderNote(int $orderId, string $note): void
    {
        $this->post("/orders/{$orderId}/notes", [
            'note'         => $note,
            'customer_note'=> false,
        ]);
    }

    /**
     * Actualiza el estado de un pedido.
     */
    public function updateOrderStatus(int $orderId, string $status, string $note = ''): void
    {
        $data = ['status' => $status];
        if ($note) $this->addOrderNote($orderId, $note);
        $this->put("/orders/{$orderId}", $data);
    }

    /**
     * Añade meta_data a un pedido (para guardar ID del albarán de SAGE).
     */
    public function setOrderMeta(int $orderId, string $key, string $value): void
    {
        // Obtener meta_data actuales y añadir la nueva entrada
        $order = $this->get("/orders/{$orderId}");
        $meta  = $order['meta_data'] ?? [];
        $meta[] = ['key' => $key, 'value' => $value];
        $this->put("/orders/{$orderId}", ['meta_data' => $meta]);
    }

    // ══ HTTP — Métodos de bajo nivel ═════════════════════════════

    public function get(string $endpoint, array $params = []): array
    {
        $url = $this->baseUrl . $endpoint;
        if ($params) $url .= '?' . http_build_query($params);
        return $this->request('GET', $url);
    }

    private function post(string $endpoint, array $data): array
    {
        return $this->request('POST', $this->baseUrl . $endpoint, $data);
    }

    private function put(string $endpoint, array $data): array
    {
        return $this->request('PUT', $this->baseUrl . $endpoint, $data);
    }

    private function request(string $method, string $url, array $data = []): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERPWD        => $this->cfg['consumer_key'] . ':' . $this->cfg['consumer_secret'],
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } elseif ($method === 'PUT') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($err) {
            $this->log->error("WooCommerce cURL error en {$method} {$url}: {$err}");
            throw new \RuntimeException("cURL error: {$err}");
        }

        $decoded = json_decode($body, true);

        if ($code >= 400) {
            $msg = $decoded['message'] ?? $body;
            $this->log->error("WooCommerce API {$code} en {$method} {$url}: {$msg}");
            throw new \RuntimeException("WooCommerce API {$code}: {$msg}");
        }

        return $decoded ?? [];
    }
}
