#!/usr/bin/env php
<?php
/**
 * sync-catalog.php — Sincronización completa del catálogo
 *
 * Uso:
 *   php sync-catalog.php           → Sincronización normal
 *   php sync-catalog.php --dry-run → Solo simula, no escribe nada
 *   php sync-catalog.php --verbose → Muestra logs detallados
 *
 * Cron job recomendado (cada hora):
 *   0 * * * * /usr/bin/php /ruta/a/dentix-sync/sync-catalog.php >> /dev/null 2>&1
 */

define('DENTIX_SYNC_ROOT', __DIR__);
require_once __DIR__ . '/src/Logger.php';
require_once __DIR__ . '/src/SageClient.php';
require_once __DIR__ . '/src/WooClient.php';
require_once __DIR__ . '/src/Syncer.php';

use DentixSync\Logger;
use DentixSync\Syncer;

$config  = require __DIR__ . '/config.php';
$dryRun  = in_array('--dry-run', $argv ?? []);
$verbose = in_array('--verbose', $argv ?? []);

if ($dryRun) $config['sync']['dry_run'] = true;

$logger = new Logger($config['paths']['log_dir'], 'catalog', $verbose);
$logger->info('════════════════════════════════════════════');
$logger->info('  Dentix Sync — Catálogo  v1.0');
$logger->info('  ' . date('d/m/Y H:i:s'));
$logger->info('════════════════════════════════════════════');

try {
    $syncer = new Syncer($config, $logger);
    $syncer->syncCatalog();
    exit(0);
} catch (Throwable $e) {
    $logger->error('Error fatal: ' . $e->getMessage());
    $logger->error($e->getTraceAsString());
    exit(1);
}
