#!/usr/bin/env php
<?php
/**
 * sync-orders.php — Envía pedidos de WooCommerce a SAGE 50
 *
 * Uso:
 *   php sync-orders.php
 *
 * Cron job recomendado (cada 5 minutos):
 *   *\/5 * * * * /usr/bin/php /ruta/a/dentix-sync/sync-orders.php >> /dev/null 2>&1
 */

define('DENTIX_SYNC_ROOT', __DIR__);
require_once __DIR__ . '/src/Logger.php';
require_once __DIR__ . '/src/SageClient.php';
require_once __DIR__ . '/src/WooClient.php';
require_once __DIR__ . '/src/Syncer.php';

use DentixSync\Logger;
use DentixSync\Syncer;

$config  = require __DIR__ . '/config.php';
$verbose = in_array('--verbose', $argv ?? []);
$logger  = new Logger($config['paths']['log_dir'], 'orders', $verbose);

try {
    $syncer = new Syncer($config, $logger);
    $syncer->syncOrders();
    exit(0);
} catch (Throwable $e) {
    $logger->error('Error fatal en sync pedidos: ' . $e->getMessage());
    exit(1);
}
