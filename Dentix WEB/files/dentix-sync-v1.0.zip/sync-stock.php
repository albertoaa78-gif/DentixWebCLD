#!/usr/bin/env php
<?php
/**
 * sync-stock.php — Sincronización rápida de stock
 *
 * Uso:
 *   php sync-stock.php
 *
 * Cron job recomendado (cada 15 minutos):
 *   *\/15 * * * * /usr/bin/php /ruta/a/dentix-sync/sync-stock.php >> /dev/null 2>&1
 */

define('DENTIX_SYNC_ROOT', __DIR__);
require_once __DIR__ . '/src/Logger.php';
require_once __DIR__ . '/src/SageClient.php';
require_once __DIR__ . '/src/WooClient.php';
require_once __DIR__ . '/src/Syncer.php';

use DentixSync\Logger;
use DentixSync\Syncer;

$config  = require __DIR__ . '/config.php';
$verbose = in_array('--verbose', $argv ?? []);
$logger  = new Logger($config['paths']['log_dir'], 'stock', $verbose);

try {
    $syncer = new Syncer($config, $logger);
    $syncer->syncStock();
    exit(0);
} catch (Throwable $e) {
    $logger->error('Error fatal en sync stock: ' . $e->getMessage());
    exit(1);
}
